'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import {
  ArrowLeft,
  Shield,
  Users,
  Trash2,
  Edit2,
  Mail,
  Key,
  User,
  Calendar,
  Search,
  Eye,
  EyeOff,
  Settings,
  Save,
  ExternalLink,
  Copy,
  Lock,
} from 'lucide-react';

interface AdminUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  createdAt: string;
  connections: {
    id: string;
    accessToken: string | null;
    userId: number | null;
    userName: string | null;
    userPhoto: string | null;
    isActive: boolean;
    createdAt: string;
    fullTokenAvailable: boolean;
  }[];
}

interface AuthUser {
  id: string;
  email: string;
  name?: string | null;
  role?: string | null;
}

export default function AdminPage() {
  const { toast } = useToast();
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [search, setSearch] = useState('');
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [tokenDialogOpen, setTokenDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('users');

  // Edit form
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editRole, setEditRole] = useState('user');
  const [editPassword, setEditPassword] = useState('');
  const [editPasswordVisible, setEditPasswordVisible] = useState(false);

  // Token view
  const [fullToken, setFullToken] = useState<string | null>(null);
  const [tokenVisible, setTokenVisible] = useState(false);

  // Settings
  const [vkAppId, setVkAppId] = useState('');
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [settingsSaving, setSettingsSaving] = useState(false);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);
        const res = await fetch('/api/auth/session', { signal: controller.signal });
        clearTimeout(timeoutId);
        const data = await res.json();
        if (data.authenticated && data.user && data.user.role === 'admin') {
          setAuthUser(data.user);
        } else {
          window.location.href = '/';
        }
      } catch {
        window.location.href = '/login';
      } finally {
        setAuthLoading(false);
      }
    };
    checkAuth();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/users');
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users);
      }
    } catch {
      toast({ title: 'Ошибка', description: 'Не удалось загрузить пользователей', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const fetchSettings = async () => {
    try {
      setSettingsLoading(true);
      const res = await fetch('/api/admin/settings');
      if (res.ok) {
        const data = await res.json();
        setVkAppId(data.settings?.vk_app_id || '');
      }
    } catch {
      // silent
    } finally {
      setSettingsLoading(false);
    }
  };

  useEffect(() => {
    if (authUser) {
      fetchUsers();
      fetchSettings();
    }
  }, [authUser]);

  const handleSaveSettings = async () => {
    try {
      setSettingsSaving(true);
      const res = await fetch('/api/admin/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { vk_app_id: vkAppId } }),
      });
      if (res.ok) {
        toast({ title: 'Настройки сохранены', description: 'ID приложения ВК обновлён' });
      } else {
        const data = await res.json();
        toast({ title: 'Ошибка', description: data.error, variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Ошибка', description: 'Не удалось сохранить настройки', variant: 'destructive' });
    } finally {
      setSettingsSaving(false);
    }
  };

  const handleEdit = (user: AdminUser) => {
    setSelectedUser(user);
    setEditName(user.name || '');
    setEditEmail(user.email);
    setEditRole(user.role);
    setEditPassword('');
    setEditPasswordVisible(false);
    setEditDialogOpen(true);
  };

  const handleSaveEdit = async () => {
    if (!selectedUser) return;
    try {
      const body: Record<string, string> = {
        name: editName,
        email: editEmail,
        role: editRole,
      };
      if (editPassword) body.password = editPassword;

      const res = await fetch(`/api/admin/users/${selectedUser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (res.ok) {
        toast({ title: 'Обновлено', description: 'Данные пользователя обновлены' });
        setEditDialogOpen(false);
        fetchUsers();
      } else {
        toast({ title: 'Ошибка', description: data.error, variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Ошибка', description: 'Не удалось обновить', variant: 'destructive' });
    }
  };

  const handleDelete = (user: AdminUser) => {
    setSelectedUser(user);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!selectedUser) return;
    try {
      const res = await fetch(`/api/admin/users/${selectedUser.id}`, { method: 'DELETE' });
      const data = await res.json();
      if (res.ok) {
        toast({ title: 'Удалено', description: 'Пользователь удалён' });
        setDeleteDialogOpen(false);
        fetchUsers();
      } else {
        toast({ title: 'Ошибка', description: data.error, variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Ошибка', description: 'Не удалось удалить', variant: 'destructive' });
    }
  };

  const handleViewToken = async (user: AdminUser) => {
    setSelectedUser(user);
    setTokenVisible(false);
    setTokenDialogOpen(true);
    setFullToken(null);
    try {
      const res = await fetch(`/api/admin/users/${user.id}?fullToken=1`);
      if (res.ok) {
        const data = await res.json();
        if (data.user?.connections?.[0]?.accessToken) {
          setFullToken(data.user.connections[0].accessToken);
        }
      }
    } catch {
      setFullToken(null);
    }
  };

  const filteredUsers = search
    ? users.filter(u =>
        u.email.toLowerCase().includes(search.toLowerCase()) ||
        (u.name && u.name.toLowerCase().includes(search.toLowerCase()))
      )
    : users;

  const oauthEnabled = !!vkAppId.trim();

  if (authLoading) {
    return (
      <div className="h-screen bg-[#edeef0] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <svg className="animate-spin h-8 w-8 text-[#0077FF]" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
          </svg>
          <p className="text-sm text-[#818c99]">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (!authUser) return null;

  return (
    <div className="min-h-screen bg-[#edeef0] flex flex-col">
      {/* Header */}
      <header className="bg-[#0077FF] z-50 shadow-md flex-shrink-0">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-12 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => window.location.href = '/'}
              className="flex items-center gap-2 text-white/80 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-white" />
              <h1 className="text-white font-bold text-lg leading-none">Админ-панель</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-white/20 text-white border-0 text-xs">
              <Shield className="w-3 h-3 mr-1" />
              Администратор
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 py-6 w-full">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="gap-4">
          <TabsList className="bg-white rounded-xl shadow-sm border border-[#dce1e6]/50 h-11 p-1 w-full max-w-md grid grid-cols-2">
            <TabsTrigger value="users" className="gap-1.5 rounded-lg text-xs data-[state=active]:bg-[#0077FF] data-[state=active]:text-white data-[state=active]:shadow-sm text-[#222]">
              <Users className="w-3.5 h-3.5" />
              Пользователи
            </TabsTrigger>
            <TabsTrigger value="settings" className="gap-1.5 rounded-lg text-xs data-[state=active]:bg-[#0077FF] data-[state=active]:text-white data-[state=active]:shadow-sm text-[#222]">
              <Settings className="w-3.5 h-3.5" />
              Настройки
            </TabsTrigger>
          </TabsList>

          {/* ===== USERS TAB ===== */}
          <TabsContent value="users" className="mt-4">
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
              <div className="bg-white rounded-xl px-4 py-3 flex items-center gap-3 shadow-sm border border-[#dce1e6]/50">
                <div className="w-9 h-9 rounded-lg bg-[#0077FF]/10 flex items-center justify-center">
                  <Users className="w-4 h-4 text-[#0077FF]" />
                </div>
                <div>
                  <div className="text-xl font-bold text-[#222]">{users.length}</div>
                  <div className="text-[11px] text-[#818c99]">Пользователей</div>
                </div>
              </div>
              <div className="bg-white rounded-xl px-4 py-3 flex items-center gap-3 shadow-sm border border-[#dce1e6]/50">
                <div className="w-9 h-9 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-green-600" />
                </div>
                <div>
                  <div className="text-xl font-bold text-[#222]">{users.filter(u => u.role === 'admin').length}</div>
                  <div className="text-[11px] text-[#818c99]">Администраторов</div>
                </div>
              </div>
              <div className="bg-white rounded-xl px-4 py-3 flex items-center gap-3 shadow-sm border border-[#dce1e6]/50">
                <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Key className="w-4 h-4 text-amber-600" />
                </div>
                <div>
                  <div className="text-xl font-bold text-[#222]">{users.filter(u => u.connections.length > 0).length}</div>
                  <div className="text-[11px] text-[#818c99]">С ВК токеном</div>
                </div>
              </div>
              <div className="bg-white rounded-xl px-4 py-3 flex items-center gap-3 shadow-sm border border-[#dce1e6]/50">
                <div className="w-9 h-9 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Calendar className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <div className="text-xl font-bold text-[#222]">
                    {users.length > 0 ? new Date(users[0].createdAt).toLocaleDateString('ru') : '—'}
                  </div>
                  <div className="text-[11px] text-[#818c99]">Последний рег.</div>
                </div>
              </div>
            </div>

            {/* Search */}
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#818c99]" />
                <Input
                  placeholder="Поиск по email или имени..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-10 h-11 border-[#dce1e6] focus:border-[#0077FF] focus:ring-[#0077FF]/20 rounded-xl"
                />
              </div>
            </div>

            {/* Users Table / Cards */}
            <div className="bg-white rounded-2xl shadow-sm border border-[#dce1e6]/50 overflow-hidden">
              {/* Desktop table */}
              <div className="hidden md:block">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#dce1e6] bg-[#f7f8fa]">
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#818c99] uppercase tracking-wider">Пользователь</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#818c99] uppercase tracking-wider">Email / Пароль</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#818c99] uppercase tracking-wider">Роль</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#818c99] uppercase tracking-wider">ВК Токен</th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-[#818c99] uppercase tracking-wider">Дата</th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-[#818c99] uppercase tracking-wider">Действия</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map(u => (
                      <tr key={u.id} className="border-b border-[#dce1e6]/50 hover:bg-[#f7f8fa] transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-[#0077FF]/10 flex items-center justify-center text-[#0077FF] font-bold text-sm">
                              {u.name?.charAt(0)?.toUpperCase() || u.email.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-medium text-sm text-[#222]">{u.name || 'Без имени'}</p>
                              <p className="text-xs text-[#818c99]">{u.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <Lock className="w-3.5 h-3.5 text-[#818c99]" />
                            <span className="text-xs text-[#818c99]">••••••</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(u)}
                              className="h-6 px-2 text-xs text-[#0077FF] hover:text-[#0066dd]"
                            >
                              Изменить
                            </Button>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          {u.role === 'admin' ? (
                            <Badge className="bg-[#0077FF]/10 text-[#0077FF] border border-[#0077FF]/20 font-medium">
                              <Shield className="w-3 h-3 mr-1" />
                              Админ
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-100 text-gray-600 border border-gray-200 font-medium">
                              Пользователь
                            </Badge>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          {u.connections.length > 0 ? (
                            <div className="flex items-center gap-1.5">
                              <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                              <span className="text-xs text-[#818c99] font-mono">{u.connections[0].accessToken}</span>
                            </div>
                          ) : (
                            <span className="text-xs text-[#818c99]">Нет</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-sm text-[#818c99]">
                          {new Date(u.createdAt).toLocaleDateString('ru', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-end gap-1">
                            {u.connections.length > 0 && (
                              <Button variant="ghost" size="sm" onClick={() => handleViewToken(u)} className="h-8 w-8 p-0 text-[#818c99] hover:text-[#0077FF]" title="Токен">
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                            <Button variant="ghost" size="sm" onClick={() => handleEdit(u)} className="h-8 w-8 p-0 text-[#818c99] hover:text-[#0077FF]" title="Редактировать">
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            {u.id !== authUser.id && (
                              <Button variant="ghost" size="sm" onClick={() => handleDelete(u)} className="h-8 w-8 p-0 text-[#818c99] hover:text-red-600" title="Удалить">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile cards */}
              <div className="md:hidden">
                <ScrollArea className="max-h-[calc(100vh-360px)]">
                  <div className="divide-y divide-[#dce1e6]/50">
                    {filteredUsers.map(u => (
                      <div key={u.id} className="p-4 hover:bg-[#f7f8fa] transition-colors">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <div className="w-10 h-10 rounded-full bg-[#0077FF]/10 flex items-center justify-center text-[#0077FF] font-bold flex-shrink-0">
                              {u.name?.charAt(0)?.toUpperCase() || u.email.charAt(0).toUpperCase()}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <p className="font-medium text-sm text-[#222] truncate">{u.name || 'Без имени'}</p>
                                {u.role === 'admin' && <Shield className="w-3.5 h-3.5 text-[#0077FF] flex-shrink-0" />}
                              </div>
                              <p className="text-xs text-[#818c99] truncate">{u.email}</p>
                              <div className="flex items-center gap-3 mt-1">
                                <span className="flex items-center gap-1 text-xs text-[#818c99]">
                                  <Lock className="w-3 h-3" /> ••••
                                </span>
                                {u.connections.length > 0 ? (
                                  <span className="text-xs text-green-600 flex items-center gap-1">
                                    <div className="w-1.5 h-1.5 rounded-full bg-green-500" />ВК
                                  </span>
                                ) : (
                                  <span className="text-xs text-[#818c99]">Без ВК</span>
                                )}
                                <span className="text-xs text-[#818c99]">
                                  {new Date(u.createdAt).toLocaleDateString('ru')}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            {u.connections.length > 0 && (
                              <Button variant="ghost" size="sm" onClick={() => handleViewToken(u)} className="h-8 w-8 p-0 text-[#818c99]">
                                <Eye className="w-4 h-4" />
                              </Button>
                            )}
                            <Button variant="ghost" size="sm" onClick={() => handleEdit(u)} className="h-8 w-8 p-0 text-[#818c99]">
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            {u.id !== authUser.id && (
                              <Button variant="ghost" size="sm" onClick={() => handleDelete(u)} className="h-8 w-8 p-0 text-[#818c99]">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              {filteredUsers.length === 0 && (
                <div className="py-16 text-center text-[#818c99]">
                  <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p className="text-sm">Пользователи не найдены</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* ===== SETTINGS TAB ===== */}
          <TabsContent value="settings" className="mt-4">
            <div className="max-w-2xl space-y-6">
              {/* VK OAuth Settings */}
              <div className="bg-white rounded-2xl shadow-sm border border-[#dce1e6]/50 overflow-hidden">
                <div className="px-6 py-4 border-b border-[#dce1e6]/50 bg-[#f7f8fa]">
                  <h3 className="flex items-center gap-2 font-semibold text-[#222]">
                    <div className="w-8 h-8 rounded-lg bg-[#0077FF]/10 flex items-center justify-center">
                      <svg width="16" height="16" viewBox="0 0 20 20" fill="none">
                        <rect width="20" height="20" rx="4" fill="#0077FF"/>
                        <path d="M5 7h1.8c.2 0 .4.1.4.3.3.7.9 2 1.4 2.3.2.1.3 0 .3-.2v-1.4c0-.5-.2-.9-.2-.9s-.1-.2-.3-.2c-.1 0-.2-.1-.1-.2.1-.1.3-.3.6-.3h1.4c.3 0 .5.2.5.5v2.1c0 .2.2.4.3.2.4-.3 1-1.4 1.5-2.4.1-.2.2-.3.4-.3h1.5c.3 0 .5.3.3.6-.6 1-1.5 2.5-1.9 2.9-.2.2-.1.4 0 .6.5.5 1.4 1.5 1.8 2 .2.2.1.5-.2.5h-1.8c-.2 0-.3-.1-.5-.2-.4-.4-.9-1-1.3-1-.2 0-.3.1-.3.4v.5c0 .2-.2.4-.4.4h-1c-1.8 0-3.2-2.5-4.1-4.6-.1-.2 0-.4.2-.4z" fill="white"/>
                      </svg>
                    </div>
                    Подключение через ВКонтакте (OAuth)
                  </h3>
                  <p className="text-sm text-[#818c99] mt-1">
                    Настройте автоматическое получение токена для пользователей
                  </p>
                </div>
                <div className="px-6 py-5 space-y-4">
                  <div className="space-y-2">
                    <Label className="text-[#222] font-medium">ID приложения ВКонтакте</Label>
                    <Input
                      value={vkAppId}
                      onChange={e => setVkAppId(e.target.value)}
                      placeholder="Например: 12345678"
                      className="h-11 border-[#dce1e6] focus:border-[#0077FF] focus:ring-[#0077FF]/20 rounded-xl"
                    />
                    <p className="text-xs text-[#818c99]">
                      Создайте Standalone-приложение на{' '}
                      <a href="https://vk.com/editapp?act=create" target="_blank" rel="noopener noreferrer" className="text-[#0077FF] hover:underline inline-flex items-center gap-0.5">
                        vk.com/editapp <ExternalLink className="w-3 h-3" />
                      </a>{' '}
                      и укажите его ID здесь
                    </p>
                  </div>

                  {oauthEnabled && (
                    <div className="bg-[#e1f0ff] border border-[#b3d4ff] rounded-xl p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                        <span className="text-sm font-medium text-[#222]">OAuth авторизация включена</span>
                      </div>
                      <p className="text-xs text-[#818c99]">
                        Пользователи смогут подключать ВКонтакте в один клик через кнопку &quot;Подключить через ВКонтакте&quot;.
                      </p>
                      <div className="bg-white/60 rounded-lg p-3 space-y-1.5">
                        <p className="text-xs font-semibold text-[#222]">В настройках приложения ВК укажите:</p>
                        <div className="flex items-center gap-2">
                          <code className="text-xs bg-white px-2 py-1 rounded border border-[#dce1e6] text-[#222] flex-1 break-all select-all">
                            {typeof window !== 'undefined' ? `${window.location.origin}/vk-callback` : '/vk-callback'}
                          </code>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              const url = `${window.location.origin}/vk-callback`;
                              navigator.clipboard.writeText(url);
                              toast({ title: 'Скопировано', description: 'Redirect URI скопирован' });
                            }}
                            className="h-7 w-7 p-0 text-[#0077FF]"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                        <p className="text-[10px] text-[#818c99]">
                          Раздел: Настройки → Открытые API → Адрес страницы авторизации
                        </p>
                      </div>
                    </div>
                  )}

                  {!oauthEnabled && (
                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                      <p className="text-xs text-amber-700">
                        <strong>Без ID приложения</strong> пользователям придётся вручную получать и вставлять токен доступа. Укажите ID приложения, чтобы включить авторизацию в один клик.
                      </p>
                    </div>
                  )}

                  <Button
                    onClick={handleSaveSettings}
                    disabled={settingsSaving}
                    className="bg-[#0077FF] hover:bg-[#0066dd] text-white font-semibold rounded-xl h-10"
                  >
                    {settingsSaving ? (
                      <svg className="animate-spin h-4 w-4 mr-2" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/>
                      </svg>
                    ) : (
                      <Save className="w-4 h-4 mr-2" />
                    )}
                    {settingsSaving ? 'Сохранение...' : 'Сохранить настройки'}
                  </Button>
                </div>
              </div>

              {/* Instructions card */}
              <div className="bg-white rounded-2xl shadow-sm border border-[#dce1e6]/50 overflow-hidden">
                <div className="px-6 py-4 border-b border-[#dce1e6]/50 bg-[#f7f8fa]">
                  <h3 className="font-semibold text-[#222] flex items-center gap-2">
                    <ExternalLink className="w-4 h-4 text-[#0077FF]" />
                    Инструкция по настройке
                  </h3>
                </div>
                <div className="px-6 py-5 space-y-4 text-sm text-[#222]">
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-[#0077FF] text-white flex items-center justify-center text-xs font-bold flex-shrink-0">1</div>
                    <div>
                      <p className="font-medium">Создайте приложение ВКонтакте</p>
                      <p className="text-xs text-[#818c99] mt-0.5">
                        Перейдите на <a href="https://vk.com/editapp?act=create" target="_blank" rel="noopener noreferrer" className="text-[#0077FF] hover:underline">vk.com/editapp</a> и создайте Standalone-приложение
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-[#0077FF] text-white flex items-center justify-center text-xs font-bold flex-shrink-0">2</div>
                    <div>
                      <p className="font-medium">Настройте Redirect URI</p>
                      <p className="text-xs text-[#818c99] mt-0.5">
                        В настройках приложения укажите адрес: <code className="bg-[#f7f8fa] px-1.5 py-0.5 rounded text-[10px]">{'/vk-callback'}</code> вашего сайта
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-[#0077FF] text-white flex items-center justify-center text-xs font-bold flex-shrink-0">3</div>
                    <div>
                      <p className="font-medium">Скопируйте ID приложения</p>
                      <p className="text-xs text-[#818c99] mt-0.5">
                        Вставьте числовой ID приложения в поле выше и нажмите &quot;Сохранить&quot;
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-7 h-7 rounded-full bg-green-500 text-white flex items-center justify-center text-xs font-bold flex-shrink-0">✓</div>
                    <div>
                      <p className="font-medium">Готово!</p>
                      <p className="text-xs text-[#818c99] mt-0.5">
                        Теперь пользователи смогут подключать ВКонтакте в один клик
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Edit Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[#222]">
              <Edit2 className="w-5 h-5 text-[#0077FF]" />
              Редактирование пользователя
            </DialogTitle>
            <DialogDescription className="text-[#818c99]">
              Измените данные пользователя
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {/* Current user info */}
            {selectedUser && (
              <div className="flex items-center gap-3 p-3 bg-[#f7f8fa] rounded-xl border border-[#dce1e6]/50">
                <div className="w-10 h-10 rounded-full bg-[#0077FF]/10 flex items-center justify-center text-[#0077FF] font-bold">
                  {selectedUser.name?.charAt(0)?.toUpperCase() || selectedUser.email.charAt(0).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#222] truncate">{selectedUser.email}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    {selectedUser.role === 'admin' ? (
                      <Badge className="bg-[#0077FF]/10 text-[#0077FF] border border-[#0077FF]/20 text-[10px] py-0">
                        <Shield className="w-2.5 h-2.5 mr-0.5" />Админ
                      </Badge>
                    ) : (
                      <Badge className="bg-gray-100 text-gray-600 border border-gray-200 text-[10px] py-0">
                        Пользователь
                      </Badge>
                    )}
                    {selectedUser.connections.length > 0 && (
                      <span className="text-[10px] text-green-600 flex items-center gap-0.5">
                        <div className="w-1 h-1 rounded-full bg-green-500" />ВК подключён
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label className="text-[#222]">Имя</Label>
              <Input
                value={editName}
                onChange={e => setEditName(e.target.value)}
                placeholder="Имя пользователя"
                className="border-[#dce1e6] focus:border-[#0077FF] rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[#222]">Email</Label>
              <Input
                type="email"
                value={editEmail}
                onChange={e => setEditEmail(e.target.value)}
                className="border-[#dce1e6] focus:border-[#0077FF] rounded-xl"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-[#222]">Роль</Label>
              <Select value={editRole} onValueChange={setEditRole}>
                <SelectTrigger className="border-[#dce1e6] rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">Пользователь</SelectItem>
                  <SelectItem value="admin">Администратор</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-[#222] flex items-center gap-2">
                <Lock className="w-3.5 h-3.5" />
                Новый пароль
              </Label>
              <div className="relative">
                <Input
                  type={editPasswordVisible ? 'text' : 'password'}
                  value={editPassword}
                  onChange={e => setEditPassword(e.target.value)}
                  placeholder="Оставьте пустым, чтобы не менять"
                  className="border-[#dce1e6] focus:border-[#0077FF] rounded-xl pr-10"
                />
                <button
                  type="button"
                  onClick={() => setEditPasswordVisible(!editPasswordVisible)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#818c99] hover:text-[#222]"
                >
                  {editPasswordVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-xs text-[#818c99]">Минимум 6 символов. Текущий пароль неизвестен — только хранится хеш.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)} className="rounded-xl">
              Отмена
            </Button>
            <Button onClick={handleSaveEdit} className="bg-[#0077FF] hover:bg-[#0066dd] text-white rounded-xl">
              Сохранить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Trash2 className="w-5 h-5" />
              Удаление пользователя
            </DialogTitle>
            <DialogDescription className="text-[#818c99]">
              Вы уверены, что хотите удалить пользователя <strong>{selectedUser?.email}</strong>?
              Все связанные данные (ВК подключения, чаты, задачи, логи) будут удалены безвозвратно.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} className="rounded-xl">
              Отмена
            </Button>
            <Button onClick={confirmDelete} className="bg-red-600 hover:bg-red-700 text-white rounded-xl">
              Удалить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Token View Dialog */}
      <Dialog open={tokenDialogOpen} onOpenChange={setTokenDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[#222]">
              <Key className="w-5 h-5 text-[#0077FF]" />
              VK Token — {selectedUser?.email}
            </DialogTitle>
            <DialogDescription className="text-[#818c99]">
              Токен доступа ВКонтакте пользователя
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {fullToken ? (
              <div className="space-y-3">
                <div className="bg-[#f7f8fa] border border-[#dce1e6] rounded-xl p-3">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <Label className="text-xs text-[#818c99]">Токен доступа</Label>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setTokenVisible(!tokenVisible)}
                      className="h-7 px-2 text-xs text-[#0077FF]"
                    >
                      {tokenVisible ? <EyeOff className="w-3.5 h-3.5 mr-1" /> : <Eye className="w-3.5 h-3.5 mr-1" />}
                      {tokenVisible ? 'Скрыть' : 'Показать'}
                    </Button>
                  </div>
                  <p className="text-xs font-mono break-all text-[#222] select-all">
                    {tokenVisible ? fullToken : fullToken.slice(0, 15) + '••••••••••••' + fullToken.slice(-8)}
                  </p>
                </div>
                {selectedUser?.connections?.[0] && (
                  <div className="flex items-center gap-4 text-xs text-[#818c99]">
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {selectedUser.connections[0].userName || 'Без имени'}
                    </span>
                    {selectedUser.connections[0].userId && (
                      <span>ID: {selectedUser.connections[0].userId}</span>
                    )}
                  </div>
                )}
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
                  <p className="text-xs text-amber-700">
                    <strong>Внимание:</strong> Не передавайте токен третьим лицам. Он предоставляет полный доступ к аккаунту ВКонтакте.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-[#818c99]">
                <Key className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Токен не найден</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTokenDialogOpen(false)} className="rounded-xl">
              Закрыть
            </Button>
            {fullToken && (
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(fullToken);
                  toast({ title: 'Скопировано', description: 'Токен скопирован в буфер обмена' });
                }}
                className="bg-[#0077FF] hover:bg-[#0066dd] text-white rounded-xl"
              >
                Копировать
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
